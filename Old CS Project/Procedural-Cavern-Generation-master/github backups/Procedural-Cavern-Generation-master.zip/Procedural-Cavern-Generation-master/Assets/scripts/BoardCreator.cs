﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoardCreator : MonoBehaviour {

    public int mapWidth;
    public int mapHeight;
    public string seed;
    public bool useRandomSeed;
    public int smoothness;
    [Range (0, 100)] public int randomFillPercent;

    public GameObject wall;
    public GameObject floor;
    public GameObject filled;
    public GameObject[] marchingSquares;
    public GameObject roomTemplate;
    public GameObject startTile;
    public GameObject endTile;

    public int roomHeightMin;
    public int roomHeightMax;
    public int roomWidthMin;
    public int roomWidthMax;
    public int maxNumberOfRooms;

    private int[,] tiles;
    private int[,] actual;
    private List<Vector2> borderWalls;
    private Dictionary<Vector2, Direction> borders;
    private System.Random pseudoRandom;

    private Room mainMap;

    private Vector2 entrancePos;
    private Vector2 endPos;

    private GameObject wallHolder;
    private GameObject floorHolder;
    private GameObject roomHolder;
    private GameObject mainMapGO;
    
    public enum TileType
    {
        Wall,
        BorderWall,
        Floor,
        Filled,
    }

    public enum Direction
    {
        North,
        East,
        South,
        West,
    }

    public void GenerateMap()
    {
        if (seed == null)
            seed = "";

        if (useRandomSeed)
            seed = unchecked(System.DateTime.Now.Ticks.GetHashCode()).ToString();

        wallHolder = new GameObject("Wall Holder");
        floorHolder = new GameObject("Floor Holder");
        roomHolder = new GameObject("Room Holder");
        pseudoRandom = new System.Random(seed.GetHashCode());
        borders = new Dictionary<Vector2, Direction>();

        //SetupTileArray();

        //generates a full (all wall) larger map
        mainMapGO = Instantiate(roomTemplate, Vector3.zero, Quaternion.identity) as GameObject; //gameobject for the main map
        mainMap = mainMapGO.GetComponent<Room>();
        mainMap.SetupRoom(Vector3.zero, mapWidth, mapHeight, seed, 55);
        mainMap.name = "Main map";
        tiles = mainMap.GetRoomNodeLayout();
        borderWalls = mainMap.GetBorderWalls();

        //generates the cavernous rooms using the Room script
        MakeRooms();

        mainMap.FindLargestReigon(); //makes sure all parts of the map are reachable

        //for(int i = 0; i < smoothness; i++)
        //    mainMap.SmoothMap();

        //instantiation
        //InstantiateNodes();       //for debugging
        //InstantiateBorders();
        InstantiateTiles();       //instantiate the tiles one at a time, until the map is fully instantiated

    }

    void UpdateBorderWalls()
    {
        borderWalls = mainMap.GetBorderWalls();
        borders = mainMap.GetBorderDirections();
      
    }
    
    void MakeRooms()
    {
        if (maxNumberOfRooms <= 0)
            return;

        Direction wallDirection; //holds the direction the room is joining to the map with
        //int n = 50;
        //int m = 50;

        //random generation of starting room
        int randomW = pseudoRandom.Next(roomWidthMin, roomWidthMax);
        int randomH = pseudoRandom.Next(roomHeightMin, roomHeightMax);
        Vector2 randomStartPos = new Vector3(pseudoRandom.Next(1, mapWidth - randomW), pseudoRandom.Next(1, mapHeight - randomH), 0); //generates a random position on the map to start at

        GameObject startRoomGO = Instantiate(roomTemplate, Vector3.zero, Quaternion.identity, roomHolder.transform) as GameObject; //gameobject for the start room
        Room startRoom = startRoomGO.GetComponent<Room>();

        //// Makes the first room have an entrance
        //startRoom.MakeStartRoom();
        startRoom.SetupRoom(randomStartPos, randomW, randomH, seed, randomFillPercent);
        startRoom.name = "Starting room";
        AddRoomToMap(startRoom.GetRoomNodeLayout(), randomStartPos, Direction.North);

        mainMap.UpdateMap(tiles);
        UpdateBorderWalls();

        int control = 0;
        int noFails = 0; //records the number of times a room has failed to place
        maxNumberOfRooms--; //starting room counts

        while (noFails < 100) //only allows a certain number of failures before the level can be finished
        {   //will only repeat 1000 times max to stop infinite recursion
            //generate random variables for a new room
            randomW = pseudoRandom.Next(roomWidthMin, roomWidthMax);
            randomH = pseudoRandom.Next(roomHeightMin, roomHeightMax);

            randomStartPos = borderWalls[pseudoRandom.Next(0, borderWalls.Count - 1)];
            wallDirection = borders[randomStartPos];

            switch (wallDirection)
            {
                case Direction.North:
                    //do nothing
                    //randomStartPos = randomStartPos + new Vector2(randomW, 0);
                    break;
                case Direction.East:
                    //do nothing
                    //randomStartPos = randomStartPos + new Vector2(0, randomH);
                    break;

                case Direction.South:
                    //decrement y value by the room's height
                    randomStartPos = randomStartPos - new Vector2(0, randomH);
                    break;
                case Direction.West:
                    //decrement x value by the room's width
                    randomStartPos = randomStartPos - new Vector2(randomW, 0);
                    break;
            }

            if (randomStartPos.x < 0 || randomStartPos.x + randomW >= mapWidth || randomStartPos.y < 0 || randomStartPos.y + randomH >= mapHeight)
            {
                //if room would overlap the edges of the map
                Debug.Log("Room failed to place, trying again...");
                noFails++; //room placement has failed so generate a new room
                continue;
            }

            //only created if the room can be placed on the map
            GameObject tempRoom = Instantiate(roomTemplate, Vector3.zero, Quaternion.identity, roomHolder.transform) as GameObject;
            tempRoom.name = tempRoom.GetHashCode().ToString();
            Room tempRoomScript = tempRoom.GetComponent<Room>();
            tempRoomScript.SetupRoom(randomStartPos, randomW, randomH, seed, randomFillPercent);
            AddRoomToMap(tempRoomScript.GetRoomNodeLayout(), randomStartPos, wallDirection);

            //entrance and exit
            if (tempRoomScript.isStartRoom)
            {
                entrancePos = tempRoomScript.entrancePos;
            } else if (tempRoomScript.isEndRoom)
            {
                endPos = tempRoomScript.endPos;
            }

            tempRoomScript.facingDirection = wallDirection;
            UpdateBorderWalls();

            mainMap.UpdateMap(tiles); //keeps the main map's tile array up-to-date
            control++;
        }

    }

    // works fine except needs to add from the actual floor tiles in the room not the bottom left corner of the room
    void AddRoomToMap(int[,] room, Vector3 tlPosition, Direction facingDirection)
    {
        //Debug.Log(room.Length);
        int n = 0; //these variables control the pointer position in the room array
        int m = 0; //x and y control the pointer position in the map array

        // scan to see if the room is covered in floor tiles
        bool loopFlag = true;
        bool canPlace = false;
        int counter = 0;
        int lastMove = 1;
        int multiplier = 1;

        while (loopFlag)
        {
            n = 0;
        // loop through map
            for (int x = (int)tlPosition.x; x < tlPosition.x + room.GetLength(0); x++)
            {
                m = 0; // to control iteration through room array
                for (int y = (int)tlPosition.y; y < tlPosition.y + room.GetLength(1); y++)
                {
                    if (room[n, m] == 0 && tiles[x,y] != 0)
                        canPlace = true;

                    m++;
                }
                n++;
            }
            if (canPlace)
                loopFlag = false;

            else // Spirals around start point until a satisfactory start point is found
            {
                switch (lastMove)
                {
                    case 1:
                        tlPosition.y += 1 * multiplier;
                        lastMove = 2;
                        break;
                    case 2:
                        tlPosition.x += 1 * multiplier;
                        lastMove = 3;
                        break;
                    case 3:
                        tlPosition.y -= 1 * multiplier;
                        lastMove = 4;
                        break;
                    case 4:
                        tlPosition.x -= 1 * multiplier;
                        lastMove = 1;
                        multiplier++;
                        break;

                }
            }
            if (tlPosition.x < float.Epsilon || tlPosition.x >= mapWidth || tlPosition.y < float.Epsilon || tlPosition.y >= mapHeight)
                return;

            counter++;
        }

        n = 0;
        // actually add the room to the map
        for (int x = (int) tlPosition.x; x < tlPosition.x + room.GetLength(0); x++)
        {
            m = 0;
            for (int y = (int)tlPosition.y; y < tlPosition.y + room.GetLength(1); y++)
            {
                if (x >= mapWidth || y >= mapHeight || x < 0 || y < 0)
                    continue;

                if (room[n, m] == 0)
                {//only floor tiles are added
                    int t = room[n, m];
                    //Debug.Log(tiles.GetLength(0) + ", " + tiles.GetLength(1));
                    //Debug.Log(x + ", " + y);
                    tiles[x, y] = t;
                }

                m++;
            }
            n++;
        }
    }

    void SetupTileArray()
    {
        tiles = new int[mapWidth, mapHeight];
        for (int x = 0; x < mapWidth; x++)
        {
            for (int y = 0; y < mapHeight; y++)
            {
                if (x == 0 || x == mapWidth - 1 || y == 0 || y == mapHeight - 1)
                {
                    tiles[x, y] = 1;
                }
                else
                {
                    //sets the tile to a 1 or 0 randomly depending on the randomFillPercent chosen
                    tiles[x, y] = (pseudoRandom.Next(0, 100) < randomFillPercent) ? 1 : 0;
                }
            }
        }
    }

    void CreateBorderWalls()
    {
        //this loop creates "border walls" which border a floor
        for (int x = 0; x < tiles.GetLength(0); x++)
        {
            for (int y = 0; y < tiles.GetLength(1); y++)
            {
                foreach (Vector2 pos in GetSurroundingTiles(new Vector2(x, y)))
                {
                    //Debug.Log("X:" + pos.x + "\nY:" + pos.y);
                    //walls will be touching a floor tile
     //               if (tiles[(int)pos.x, (int)pos.y] == TileType.Floor && tiles[x, y] == TileType.Wall)
                    {
                        //Debug.Log("border");
       //                 tiles[x, y] = TileType.BorderWall;
                        break;
                    }

                }
            }
        }
    }

    int NeighbourCountOf(Vector2 tilePos)
    {
        int score = 0;
        for (int x = (int)tilePos.x - 1; x <= tilePos.x + 1; x++)
        {
            for (int y = (int)tilePos.y - 1; y <= tilePos.y + 1; y++)
            {
                if (x >= mapWidth || y >= mapHeight || x < 0 || y < 0)
                {
                    //selecting a square that hasn't been instantiated because it is out of bounds
                    score++;
                    continue;
                }
                else if (x == tilePos.x && y == tilePos.y)
                {
                    //selecting itself
                    continue;
                }

                //increments return value if there is a wall there
         //       score += (tiles[x, y] == TileType.Wall) ? 1 : 0;
            }
        }

        return score;
    }

    Vector2[] GetSurroundingTiles(Vector2 pos)
    {
        List<Vector2> neighbours = new List<Vector2>();
        for (int x = (int)pos.x - 1; x <= pos.x + 1; x++)
        {
            for (int y = (int)pos.y - 1; y <= pos.y + 1; y++)
            {
                if (x >= mapWidth || x < 0 || y >= mapHeight || y < 0 || (x == (int)pos.x && y == (int)pos.y) || !(x == (int)pos.x || y == (int)pos.y))
                    continue;

                neighbours.Add(new Vector2(x, y));
            }
        }
        return neighbours.ToArray();
    }

    void MakeTileArrayFromNodes()
    {
        //List<List<int>> actualTemp = new List<List<int>>();
        actual = new int[mapWidth, mapHeight];
        for (int x = 0; x < tiles.GetLength(0) - 1; x++)
        {
            for (int y = 0; y < tiles.GetLength(1) - 1; y++)
            {
                // -1 because of the called method GetScore()
                Vector2 v2Pos = new Vector2(x, y);
                int tempScore = GetScoreFor(v2Pos);
                actual[x, y] = tempScore;
            }
        }

    }

    int GetScoreFor(Vector2 tlNodePos)
    {
        int bl = tiles[(int)tlNodePos.x, (int)tlNodePos.y];
        int br = tiles[(int)tlNodePos.x + 1, (int)tlNodePos.y];
        int tl = tiles[(int)tlNodePos.x, (int)tlNodePos.y + 1];
        int tr = tiles[(int)tlNodePos.x + 1, (int)tlNodePos.y + 1];

        int[] nodeArray = new int[4] { bl, br, tr, tl };

        int score = 0;

        for (int n = 0; n < nodeArray.GetLength(0); n++)
        {
            int s = nodeArray[n];
            if (s == 1)
            {
                score += (int)Mathf.Pow(2f, n); //adds the binary value of the node to the score for the tile
            }

        }

        return score;
    }

    void InstantiateTiles()
    {
        if (endPos != null)
            Instantiate(endTile, endPos, Quaternion.identity, wallHolder.transform);
        else if (entrancePos != null)
            Instantiate(startTile, entrancePos, Quaternion.identity, wallHolder.transform);

        actual = mainMap.GetRoomTileLayout();

        for (int x = 0; x < actual.GetLength(0); x++)
        {
            for (int y = 0; y < actual.GetLength(1); y++)
            {
                if (actual[x, y] != 15 && actual[x, y] != 0)
                {
                    GameObject tilem = Instantiate(marchingSquares[0], new Vector3(x, y, 0f), Quaternion.identity, floorHolder.transform) as GameObject;
                    tilem.name = "Compensation";
                }

                GameObject tile = Instantiate(marchingSquares[actual[x,y]], new Vector3(x, y, 0f), Quaternion.identity, mainMapGO.transform) as GameObject;
                //Debug.Log(tile.transform.position);
            }
        }
    }

    void InstantiateNodes()
    {
        tiles = mainMap.GetRoomNodeLayout();
        for (int x = 0; x < tiles.GetLength(0); x++)
        {
            for (int y = 0; y < tiles.GetLength(1); y++)
            {
                if (tiles[x,y] == 1)
                    Instantiate(wall, new Vector3(x,y, 0f), Quaternion.identity, wallHolder.transform);
            }
        }
    }

    void InstantiateBorders()
    {
        foreach (Vector2 x in borderWalls)
        { 
            Instantiate(filled, x, Quaternion.identity, wallHolder.transform);
        }
    }
}
