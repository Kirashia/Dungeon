﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MovingObject {

    public bool dead = false;

    private Rigidbody2D rb2d;
    [SerializeField] private float moveSpeed;

    public void Awake()
    {
        rb2d = GetComponent<Rigidbody2D>();
    }

    public override IEnumerator Move()
    {
        float horizontal = Input.GetAxis("Horizontal") * Time.deltaTime * moveSpeed;
        float vertical = Input.GetAxis("Vertical") * Time.deltaTime * moveSpeed;

        rb2d.velocity = new Vector2(horizontal, vertical);
        yield return null;
    }

    public override IEnumerator Attack()
    {
        yield return null;
    }

    public IEnumerator ChangeDirection()
    {
        yield return null;
    }
	
	void Update ()
    {
        //StartCoroutine(Move());
        float horizontal = Input.GetAxis("Horizontal") * Time.deltaTime * moveSpeed;
        float vertical = Input.GetAxis("Vertical") * Time.deltaTime * moveSpeed;

        rb2d.velocity = new Vector2(horizontal, vertical);
    }

}
