﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class MovingObject : MonoBehaviour {

    public abstract IEnumerator Move();

    public abstract IEnumerator Attack();

    public Vector3 GetPosition()
    {
        return transform.position;
    }
}
