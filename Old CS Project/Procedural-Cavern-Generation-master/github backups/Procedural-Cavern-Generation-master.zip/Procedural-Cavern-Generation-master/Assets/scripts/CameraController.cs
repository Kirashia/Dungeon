﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {

    private Rigidbody2D rb2d;
    private PlayerController playerController;
	// Use this for initialization
	void Start () {
        rb2d = GetComponent<Rigidbody2D>();
        playerController = GetComponentInParent<PlayerController>();

        transform.position = playerController.transform.position;
	}
}
